#include <iostream>

int main()
{
    bool flag = true;
    printf("Value of flag = %d", flag);
    printf("\nSize of flag = %d", sizeof(flag));
    return 0;
}