#include <iostream>
using namespace std;
int main()
{
    int num1;
    cout << "Hello world" << endl; //printf()
    cout << "Enter the value of num1 = ";
    cin >> num1; //scanf()
    cout << "Value of num1 = " << num1 << endl;
    return 0;
}
